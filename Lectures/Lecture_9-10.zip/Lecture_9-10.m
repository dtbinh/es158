% Equations of motion

